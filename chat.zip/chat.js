var Messages = [];
var LastId = 0;
var UserName = '';

$(document).ready(function() {
    loadData();
    $('.message__delete').on('click', removeMessage);
    $('#nameButton').on('click', beginChat);
    $('#sendButton').on('click', sendMessage);
});

function removeMessage(event) {
    var messageIndex = $(event.currentTarget).parents(".message").attr('data-id');
    for (var i = Messages.length - 1; i >= 0; i--) {
        if (Messages[i].id == messageIndex) {
            $('.message[data-id=\"' + Messages[i].id + '\"]').remove();
            Messages.splice(i, 1);
        }
    }
}

function beginChat() {
    UserName = $('#nameText').val();
    $('.login').css('display', 'none');
    $('.content__window').css('display', 'block');
    $('#sendText').attr('placeholder', 'Hello, ' + UserName + '!');
}

function sendMessage() {
    var date = new Date();
    Messages.push({
        id: ++LastId,
        name: UserName,
        date: date.toLocaleString(),
        text: $('#sendText').val()
    });
    $('#sendText').val('');

    localStorage.setItem('result', JSON.stringify(Messages));

    $(".content__window").append('<div class="message" data-id="' + Messages[Messages.length-1].id + '"><div class="message__info">'
        + '<div class="user-info"><div class="message__author">' + Messages[Messages.length-1].name + '</div>'
        + '<div class="message__date">' + Messages[Messages.length-1].date.toLocaleString() +'</div></div><div class="user-control">'
        + '<div class="message__edit">edit</div><div class="message__delete">delete</div>'
        + '</div></div><div class="message__text">' + Messages[Messages.length-1].text + '</div></div>');
}

function loadData() {
    if (localStorage.length) {
        Messages = $.parseJSON(localStorage.getItem('result'));
        LastId = Messages[Messages.length - 1].id;
        $.each(Messages, function(index, element) {
            $(".content__window").append('<div class="message" data-id="' + element.id + '"><div class="message__info">'
                + '<div class="user-info"><div class="message__author">' + element.name + '</div>'
                + '<div class="message__date">' + element.date +'</div></div><div class="user-control">'
                + '<div class="message__edit">edit</div><div class="message__delete">delete</div>'
                + '</div></div><div class="message__text">' + element.text + '</div></div>');
        });
    }
}

